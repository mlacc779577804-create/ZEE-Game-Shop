ZEE Game Shop — Marketplace website prototype

Open index.html in a browser to preview.
This is a front-end demo only:
- Listings are sample data.
- New listings exist only in the current page session and are not uploaded to a server.
- No real login, database, payment, escrow, or admin approval is connected.

For a live marketplace, the next build needs:
1. Hosting + domain
2. Database and user accounts (buyer/seller/admin)
3. Admin moderation and listing approval
4. Seller contact / order workflow
5. A verified local payment flow and clear dispute/refund policy

Do not collect or display passwords, OTPs, recovery codes, or other account credentials in public listings.
